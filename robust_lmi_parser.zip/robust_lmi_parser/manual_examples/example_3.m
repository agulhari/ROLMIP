clear;

poly_I = rolmipvar(eye(3),'I');
