clear;

poly_P = rolmipvar(3,3,'P','symmetric',{[0 0],[1 0],[0 3],[2 4]},[-2 3; -4 8]);
